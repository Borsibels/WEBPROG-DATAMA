<?php
// dashboard.php

session_start();
include 'conn.php';

// Check if user is logged in
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}

$adopterID = $_SESSION['AdopterID']; // Use AdopterID from session
$sql = "SELECT * FROM pet_tbl WHERE AdopterID = '$adopterID'";
$result = $con->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="https://kit.fontawesome.com/261742be5d.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Animal Dashboard</title>
    <link rel="stylesheet" href="src/style.css">
    <script src="src/script.js"></script>
</head>
<body>
    <button class="sidebar-toggle">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="sidebar">
        <div class="user-profile">
            <img src="<?php echo !empty($userData['ProfilePic']) ? $userData['ProfilePic'] : '/petAdopt/img/default-avatar.png'; ?>" alt="User Profile">
            <h3>Welcome, <?php echo isset($_SESSION['fname']) ? $_SESSION['fname'] : 'Guest'; ?></h3>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="petregist.php"><i class="fas fa-plus"></i> Register Pet</a></li>
            <li><a href="#"><i class="fas fa-heart"></i> Favorites</a></li>
            <li><a href="#"><i class="fas fa-history"></i> Adoption History</a></li>
            <li><a href="shelterregist.php"><i class="fas fa-house-user"></i> Shelter Owner? Register With Us!</a></li>
            <?php if (isset($_SESSION['username'])): ?>
            <li><a href="logout.php" class="logout">Logout</a></li>
            <?php else: ?>
            <li><a href="login.php" class="login">Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
    <header>
        <div class="logo">
            <img src="/petAdopt/img/logo.png" alt="Pet Adopt Logo">
            <h1>PET ADOPT</h1>
        </div>
        <nav>
            <ul>
                <li><a href="about.php">ABOUT US</a></li>
                <li><a href="dashboard.php">Find Your New Pet</a></li>
                <?php if (!isset($_SESSION['username'])): ?>
                    <li><a href="signup.php" class="signup">SIGN UP</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <h1>Available Animals</h1>

    <table style='width: 100%; border-collapse: collapse;'>
        <tr style='background-color: #f2f2f2;'>
            <th style='padding: 8px; border: 1px solid #ddd;'>Pet ID</th>
            <th style='padding: 8px; border: 1px solid #ddd;'>Type</th>
            <th style='padding: 8px; border: 1px solid #ddd;'>Breed</th>
            <th style='padding: 8px; border: 1px solid #ddd;'>Gender</th>
            <th style='padding: 8px; border: 1px solid #ddd;'>Description</th>
            <th style='padding: 8px; border: 1px solid #ddd;'>Age</th>
            <th style='padding: 8px; border: 1px solid #ddd;'>Size</th>
            <th style='padding: 8px; border: 1px solid #ddd;'>Address</th>
            <th style='padding: 8px; border: 1px solid #ddd;'>Photo</th>
        </tr>
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td style='padding: 8px; border: 1px solid #ddd;'><?= $row["PetID"] ?></td>
                    <td style='padding: 8px; border: 1px solid #ddd;'><?= $row["PetType"] ?></td>
                    <td style='padding: 8px; border: 1px solid #ddd;'><?= $row["Breed"] ?></td>
                    <td style='padding: 8px; border: 1px solid #ddd;'><?= $row["Gender"] ?></td>
                    <td style='padding: 8px; border: 1px solid #ddd;'><?= $row["Description"] ?></td>
                    <td style='padding: 8px; border: 1px solid #ddd;'><?= $row["Age"] ?></td>
                    <td style='padding: 8px; border: 1px solid #ddd;'><?= $row["Size"] ?></td>
                    <td style='padding: 8px; border: 1px solid #ddd;'><?= $row["Address"] ?></td>
                    <td style='padding: 8px; border: 1px solid #ddd;'><img src='data:image/jpeg;base64,<?= base64_encode($row['PetPhoto']) ?>' width='100'/></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="9" style='padding: 8px; border: 1px solid #ddd;'>No pets registered.</td></tr>
        <?php endif; ?>
    </table>
</body>
</html>