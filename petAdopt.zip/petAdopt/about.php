<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="https://kit.fontawesome.com/261742be5d.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="src/style.css">
</head>
<body>
    <button class="sidebar-toggle">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="sidebar">
        <div class="user-profile">
        <img src="<?php echo !empty($userData['ProfilePic']) ? $userData['ProfilePic'] : '/petAdopt/img/default-avatar.png'; ?>" alt="User Profile">
            <h3>Welcome, <?php echo isset($_SESSION['fname']) ? $_SESSION['fname'] : 'Guest'; ?></h3>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="petregist.php"><i class="fas fa-plus"></i> Register Pet</a></li>
            <li><a href="#"><i class="fas fa-heart"></i> Favorites</a></li>
            <li><a href="#"><i class="fas fa-history"></i> Adoption History</a></li>
            <li><a href="shelterregist.php"><i class="fas fa-house-user"></i> Shelter Owner? Register With Us!</li></a></li>
            <?php if (isset($_SESSION['username'])): ?>
                <li><a href="logout.php" class="logout">Logout</a></li>
            <?php else: ?>
                <li><a href="index.php" class="logout">Logout</a></li>
            <?php endif; ?>
        </ul>
    </div>
    <header>
        <div class="logo">
            <img src="/petAdopt/img/logo.png" alt="Pet Adopt Logo">
            <a></a><h1>PET ADOPT</h1></a>
        </div>
        <nav>
            <ul>
            <li><a href="about.php">ABOUT US</a></li>
            <li><a href="dashboard.php">Find Your New Pet</a></li>
                <?php if (isset($_SESSION['username'])): ?>
                    <li><a href="logout.php" class="logout">Logout</a></li>
                <?php else: ?>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <main class="main-content">
        <section class="about-us">
            <div class="content-wrapper fade-in">
                <h2>Our Mission</h2>
                <p>Many shelters deal with the dual problems of little money and low visibility in their areas as the number of animals in shelters keeps growing. The goal of this project is to develop an easy-to-use website that highlights nearby animal shelters, the creatures they have up for adoption, and the advantages of pet adoption. The website can help foster relationships between shelters and potential pet owners by offering a consolidated resource for pet adoption, which would ultimately boost adoption rates and enhance animal welfare.</p>
            </div>
        </section>

        <section class="team">
            <div class="content-wrapper fade-in">
                <h2>Meet Our Team</h2>
                <div class="team-grid">
                    <div class="team-member">
                        <img src="antonio.jpg" alt="Antonio, Viancielle">
                        <h3>Antonio, Viancielle</h3>
                        <p>Role or Title</p>
                    </div>
                    <div class="team-member">
                        <img src="atienza.jpg" alt="Atienza, Maria Xandra Angelica M.">
                        <h3>Atienza, Maria Xandra Angelica M.</h3>
                        <p>Role or Title</p>
                    </div>
                    <div class="team-member">
                        <img src="cometa.jpg" alt="Cometa, Oliver King">
                        <h3>Cometa, Oliver King</h3>
                        <p>Role or Title</p>
                    </div>
                    <div class="team-member">
                        <img src="santos.jpg" alt="Santos, Gabriel">
                        <h3>Santos, Gabriel</h3>
                        <p>Role or Title</p>
                    </div>
                    <div class="team-member">
                        <img src="taupa.jpg" alt="Taupa, Mavrick DJ">
                        <h3>Taupa, Mavrick DJ</h3>
                        <p>Role or Title</p>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2023 Pet Adopt. All rights reserved.</p>
    </footer>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const fadeElements = document.querySelectorAll('.fade-in');
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                    }
                });
            }, {
                threshold: 0.1
            });

            fadeElements.forEach(element => {
                observer.observe(element);
            });
        });
    </script>
    <script src="src/script.js"></script>
</body>
</html>