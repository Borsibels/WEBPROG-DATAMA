<?php
session_start();
$_SESSION['loggedin'] = true;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="https://kit.fontawesome.com/261742be5d.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Adopt</title>
    <link rel="stylesheet" href="src/style.css">
    <script src="src/script.js"></script>
</head>
<body>
    <button class="sidebar-toggle">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="sidebar">
        <div class="user-profile">
            <img src="<?php echo !empty($userData['ProfilePic']) ? $userData['ProfilePic'] : '/petAdopt/img/default-avatar.png'; ?>" alt="User Profile">
            <h3>Welcome, <?php echo isset($_SESSION['fname']) ? $_SESSION['fname'] : 'Guest'; ?></h3>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="petregist.php"><i class="fas fa-plus"></i> Register Pet</a></li>
            <li><a href="#"><i class="fas fa-heart"></i> Favorites</a></li>
            <li><a href="#"><i class="fas fa-history"></i> Adoption History</a></li>
            <li><a href="shelterregist.php"><i class="fas fa-house-user"></i> Shelter Owner? Register With Us!</li></a></li>
            <?php if (isset($_SESSION['username'])): ?>
            <li><a href="logout.php" class="logout">Logout</a></li>
            <?php else: ?>
            <li><a href="login.php" class="login">Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
    <header>
        <div class="logo">
            <img src="/petAdopt/img/logo.png" alt="Pet Adopt Logo">
            <a></a><h1>PET ADOPT</h1></a>
        </div>
        <nav>
            <ul>
                <li><a href="about.php">ABOUT US</a></li>
                <li><a href="dashboard.php">Find Your New Pet</a></li>
                <?php if (!isset($_SESSION['username'])): ?>
                    <li><a href="signup.php" class="signup">SIGN UP</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <div class="hero">
        <div class="search-container">
            <input type="text" placeholder="Search Dogs, kittens etc." class="search-box">
            <input type="text" placeholder="Enter City, State or ZIP" class="search-box">
            <button><i class="fa-solid fa-magnifying-glass"></i></button>
        </div>
        <h2 class="fade-in">FIND YOUR NEW HOME</h2>
    </div>

    <section class="categories">
        <div class="category fade">
            <div class="icon cat"></div>
            <p>Cats</p>
        </div>
        <div class="category fade">
            <div class="icon dog"></div>
            <p>Dogs</p>
        </div>
        <div class="category fade">
            <div class="icon other"></div>
            <p>Other Animals</p>
        </div>
        <div class="category fade">
            <div class="icon shelter"></div>
            <p>Shelters and Rescues</p>
        </div>
    </section>

    <center>
        <p>&copy; 2023 Pet Adopt. All rights reserved.</p>
    </center>
</body>
</html>