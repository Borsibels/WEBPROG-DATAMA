<?php
session_start();
include('conn.php');

if (isset($_POST['btn_login'])) {
    $username = $_POST['txt_username'];
    $password = $_POST['txt_password'];

    // Fetch the user's AdopterID, first name, username, and password
    $sql = "SELECT `AdopterID`, `Username`, `Fname` FROM `adopter_tbl` WHERE `Username` = '$username' AND `Password` = '$password'";
    $res = $con->query($sql);

    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $_SESSION['AdopterID'] = $row['AdopterID']; // Set session variable for AdopterID
        $_SESSION['username'] = $username; // Set session variable for username
        $_SESSION['fname'] = $row['Fname']; // Set session variable for first name
        $_SESSION['loggedin'] = true; // Set session variable for logged in status
        echo "<script>alert('Login successful'); window.location.href = 'index.php';</script>";
    } else {
        echo "<script>alert('Invalid username or password');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="https://kit.fontawesome.com/261742be5d.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Adopt</title>
    <link rel="stylesheet" href="src/style.css">
</head>
<body>
    <button class="sidebar-toggle">
        <i class="fas fa-bars"></i>
    </button>

    <div class="sidebar">
        <div class="user-profile">
        <img src="<?php echo !empty($userData['ProfilePic']) ? $userData['ProfilePic'] : '/petAdopt/img/default-avatar.png'; ?>" alt="User Profile">
            <h3>Welcome, <?php echo isset($_SESSION['fname']) ? $_SESSION['fname'] : 'Guest'; ?></h3>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="petregist.php"><i class="fas fa-plus"></i> Register Pet</a></li>
            <li><a href="#"><i class="fas fa-heart"></i> Favorites</a></li>
            <li><a href="#"><i class="fas fa-history"></i> Adoption History</a></li>
            <li><a href="#"><i class="fas fa-house-user"></i> Shelter Owner? Register With Us!</li></a></li>
                <?php if (isset($_SESSION['username'])): ?>
                    <li><a href="logout.php" class="logout">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php" class="login">Login</a></li>
                <?php endif; ?>
        </ul>
    </div>
    <header>
    <div class="logo">
            <img src="/petAdopt/img/logo.png" alt="Pet Adopt Logo">
            <a></a><h1>PET ADOPT</h1></a>
        </div>
        <nav>
        <ul>
        <li><a href="about.php">ABOUT US</a></li>
        <li><a href="dashboard.php">Find Your New Pet</a></li>
            <?php if (!isset($_SESSION['username'])): ?>
                <li><a href="signup.php" class="signup">SIGN UP</a></li>
            <?php endif; ?>
        </ul>
        </nav>
    </header>

    <div class="main-content">
        <div class="content-wrapper">
            <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); max-width: 600px; margin: 0 auto;">
                <h2 style="color: #007bff; text-align: center; margin-bottom: 30px;">Login</h2>
                <form action="login.php" method="post" style="display: flex; flex-direction: column; gap: 15px;">
                    <div class="form-group fade-in" style="display: flex; flex-direction: column;">
                        <label for="txt_username" style="margin-bottom: 5px;">Enter username*</label>
                        <input type="text" required name="txt_username" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>

                    <div class="form-group fade-in" style="display: flex; flex-direction: column;">
                        <label for="txt_password" style="margin-bottom: 5px;">Enter password*</label>
                        <input type="password" required name="txt_password" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>

                    <div style="text-align: center; margin-top: 20px;">
                        <input type="submit" name="btn_login" value="Login" class="login-btn">
                    </div>
                </form>
                <div style="text-align: center; margin-top: 20px;">
                    <a href="signup.php" style="color: #007bff; text-decoration: none;">Don't have an account? Sign up here.</a>
                </div>
            </div>
        </div>
    </div>
    <script src="src/script.js"></script>
</body>
</html>



