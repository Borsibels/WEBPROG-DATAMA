<?php
// shelterregist.php
session_start();
$_SESSION['loggedin'] = true;
include 'conn.php';


// Check if user is logged in
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $shelterName = $_POST['shelterName'];
    $contactNumb = $_POST['contactNumb'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $shelterPhoto = addslashes(file_get_contents($_FILES['shelterPhoto']['tmp_name']));

    $sql = "INSERT INTO shelter_tbl (ShelterName, Contactnumb, Email, Address, ShelterPhoto) VALUES ('$shelterName', '$contactNumb', '$email', '$address', '$shelterPhoto')";

    if ($con->query($sql) === TRUE) {
        echo "Shelter registered successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="https://kit.fontawesome.com/261742be5d.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Shelter Owner</title>
    <link rel="stylesheet" href="src/style.css">
    <script src="src/script.js"></script>
</head>
<body>
    <button class="sidebar-toggle">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="sidebar">
        <div class="user-profile">
            <img src="<?php echo !empty($userData['ProfilePic']) ? $userData['ProfilePic'] : '/petAdopt/img/default-avatar.png'; ?>" alt="User Profile">
            <h3>Welcome, <?php echo isset($_SESSION['fname']) ? $_SESSION['fname'] : 'Guest'; ?></h3>
        </div>
        <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="petregist.php"><i class="fas fa-plus"></i> Register Pet</a></li>
            <li><a href="#"><i class="fas fa-heart"></i> Favorites</a></li>
            <li><a href="#"><i class="fas fa-history"></i> Adoption History</a></li>
            <li><a href="shelterregist.php"><i class="fas fa-house-user"></i> Shelter Owner? Register With Us!</a></li>
            <?php if (isset($_SESSION['username'])): ?>
            <li><a href="logout.php" class="logout">Logout</a></li>
            <?php else: ?>
            <li><a href="login.php" class="login">Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
    <header>
        <div class="logo">
            <img src="/petAdopt/img/logo.png" alt="Pet Adopt Logo">
            <h1>PET ADOPT</h1>
        </div>
        <nav>
            <ul>
                <li><a href="about.php">ABOUT US</a></li>
                <li><a href="dashboard.php">Find Your New Pet</a></li>
                <?php if (!isset($_SESSION['username'])): ?>
                    <li><a href="signup.php" class="signup">SIGN UP</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <div class="main-content">
        <div class="content-wrapper">
            <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); max-width: 600px; margin: 0 auto;">
                <h2 style="color: #007bff; text-align: center; margin-bottom: 30px;">Register a Shelter Owner</h2>
                <form action="shelterregist.php" method="post" enctype="multipart/form-data" style="display: flex; flex-direction: column; gap: 15px;">
                    <div class="form-group fade-in" style="--order: 1; display: flex; flex-direction: column;">
                        <label for="shelterName" style="margin-bottom: 5px;">Shelter Name*</label>
                        <input type="text" name="shelterName" placeholder="Shelter Name" required style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group fade-in" style="--order: 2; display: flex; flex-direction: column;">
                        <label for="contactNumb" style="margin-bottom: 5px;">Contact Number*</label>
                        <input type="number" name="contactNumb" placeholder="Contact Number" required style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group fade-in" style="--order: 3; display: flex; flex-direction: column;">
                        <label for="email" style="margin-bottom: 5px;">Email*</label>
                        <input type="email" name="email" placeholder="Email" required style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group fade-in" style="--order: 4; display: flex; flex-direction: column;">
                        <label for="address" style="margin-bottom: 5px;">Address*</label>
                        <input type="text" name="address" placeholder="Address" required style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group fade-in" style="--order: 5; display: flex; flex-direction: column;">
                        <label for="shelterPhoto" style="margin-bottom: 5px;">Shelter Photo*</label>
                        <input type="file" name="shelterPhoto" required style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div style="text-align: center; margin-top: 20px;">
                        <input type="submit" value="Register Shelter" class="register-btn">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>