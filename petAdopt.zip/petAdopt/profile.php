<?php
session_start();
$_SESSION['loggedin'] = true;
include('conn.php');

// Fetch existing user data
$username = $_SESSION['username'] ?? null;

if ($username) {
    $sqlFetch = "SELECT * FROM `adopter_tbl` WHERE `Username` = '$username'";
    $result = $con->query($sqlFetch);

    if ($result && $result->num_rows > 0) {
        $userData = $result->fetch_assoc();
    } else {
        echo "<script>alert('User data not found');</script>";
        // Optionally redirect to another page or handle the error
        $userData = [
            'Username' => '',
            'Lname' => '',
            'Fname' => '',
            'Mname' => '',
            'ContactNo' => '',
            'Email' => '',
            'Address' => ''
        ];
    }
} else {
    echo "<script>alert('User not logged in');</script>";
    // Optionally redirect to login page
    $userData = [
        'Username' => '',
        'Lname' => '',
        'Fname' => '',
        'Mname' => '',
        'ContactNo' => '',
        'Email' => '',
        'Address' => ''
    ];
}

if (isset($_POST['btn_update'])) {
    $un = $_POST['txt_username'];
    $sn = $_POST['txt_surname'];
    $gn = $_POST['txt_givenName'];
    $cn = $_POST['txt_cn'];
    $email = $_POST['txt_Email'];
    $address = $_POST['txt_address'];
    $mn = $_POST['txt_middleName'] ?? '';

    // Debugging: Check if contact number is received
    // echo "<script>console.log('Contact Number: $cn');</script>";

    $sqlUpdate = "UPDATE `adopter_tbl` SET 
                  `Username` = '$un', 
                  `Lname` = '$sn', 
                  `Fname` = '$gn', 
                  `Mname` = '$mn', 
                  `ContactNo` = '$cn', 
                  `Email` = '$email', 
                  `Address` = '$address' 
                  WHERE `Username` = '{$_SESSION['username']}'";

    if ($con->query($sqlUpdate) === TRUE) {
        echo "<script>alert('Profile updated successfully');</script>";
    } else {
        echo "<script>alert('Profile update failed');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="https://kit.fontawesome.com/261742be5d.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="src/style.css">
    <script src="src/script.js"></script>
    <title>Profile</title>
</head>
<body>
    <button class="sidebar-toggle">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="sidebar">
        <div class="user-profile">
            <img src="<?php echo !empty($userData['ProfilePic']) ? $userData['ProfilePic'] : '/petAdopt/img/default-avatar.png'; ?>" alt="User Profile">
            <h3>Welcome, <?php echo isset($_SESSION['fname']) ? $_SESSION['fname'] : 'Guest'; ?></h3>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="#"><i class="fas fa-heart"></i> Favorites</a></li>
            <li><a href="#"><i class="fas fa-history"></i> Adoption History</a></li>
            <li><a href="shelterregist.php"><i class="fas fa-house-user"></i> Shelter Owner? Register With Us!</li></a></li>
            <?php if (isset($_SESSION['username'])): ?>
            <li><a href="logout.php" class="logout">Logout</a></li>
            <?php else: ?>
            <li><a href="login.php" class="login">Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
    <header>
        <div class="logo">
            <img src="/petAdopt/img/logo.png" alt="Pet Adopt Logo">
            <h1>PET ADOPT</h1>
        </div>
        <nav>
            <ul>
                <li><a href="about.php">ABOUT US</a></li>
                <li><a href="#">OTHER TYPES OF PETS</a></li>
                <li><a href="#">DOGS AND PUPPIES</a></li>
                <li><a href="#">CATS AND KITTENS</a></li>
                <?php if (!isset($_SESSION['username'])): ?>
                    <li><a href="signup.php" class="signup">SIGN UP</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
    <div class="main-content">
        <div class="content-wrapper">
            <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); max-width: 600px; margin: 0 auto;">
                <h2 style="color: #007bff; text-align: center; margin-bottom: 30px;">Update Profile</h2>
                <form action="profile.php" method="post" enctype="multipart/form-data" style="display: flex; flex-direction: column; gap: 15px;">
                    <div class="form-group fade-in" style="--order: 1; display: flex; flex-direction: column;">
                        <label for="txt_username" style="margin-bottom: 5px;">Username*</label>
                        <input type="text" name="txt_username" value="<?php echo htmlspecialchars($userData['Username']); ?>" required style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group fade-in" style="--order: 2; display: flex; flex-direction: column;">
                        <label for="txt_surname" style="margin-bottom: 5px;">Surname*</label>
                        <input type="text" name="txt_surname" value="<?php echo htmlspecialchars($userData['Lname']); ?>" required style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group fade-in" style="--order: 3; display: flex; flex-direction: column;">
                        <label for="txt_givenName" style="margin-bottom: 5px;">Given Name*</label>
                        <input type="text" name="txt_givenName" value="<?php echo htmlspecialchars($userData['Fname']); ?>" required style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group fade-in" style="--order: 4; display: flex; flex-direction: column;">
                        <label for="txt_middleName" style="margin-bottom: 5px;">Middle Name</label>
                        <input type="text" name="txt_middleName" value="<?php echo htmlspecialchars($userData['Mname']); ?>" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group fade-in" style="--order: 5; display: flex; flex-direction: column;">
                        <label for="txt_cn" style="margin-bottom: 5px;">Contact Number*</label>
                        <input type="text" name="txt_cn" value="<?php echo htmlspecialchars($userData['ContactNo']); ?>" required style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group fade-in" style="--order: 6; display: flex; flex-direction: column;">
                        <label for="txt_Email" style="margin-bottom: 5px;">Email*</label>
                        <input type="email" name="txt_Email" value="<?php echo htmlspecialchars($userData['Email']); ?>" required style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group fade-in" style="--order: 7; display: flex; flex-direction: column;">
                        <label for="txt_address" style="margin-bottom: 5px;">Address*</label>
                        <input type="text" name="txt_address" value="<?php echo htmlspecialchars($userData['Address']); ?>" required style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div class="form-group fade-in" style="--order: 8; display: flex; flex-direction: column;">
                        <label for="profile_picture" style="margin-bottom: 5px;">Profile Picture</label>
                        <input type="file" name="profile_picture" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    </div>
                    <div style="text-align: center; margin-top: 20px;">
                        <input type="submit" name="btn_update" value="Update Profile" class="register-btn">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
